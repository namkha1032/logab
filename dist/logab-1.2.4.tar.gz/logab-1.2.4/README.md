# logab
A lightweight Python package for better formatting.
## Install
```
pip install logab
```
## Usage
```
pip install logab
```
## Demo
![Alt Text](demo.gif)
![Alt text](https://ngdblog.africa/wp-content/uploads/2023/01/Wow-gif.gif)
<img src="demo.gif" alt="Descriptive text" />
